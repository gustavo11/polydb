package VCFUtils;

sub alpha_order_alleles {
	my ($genotype) = @_;

	my @nt = split ",", $genotype;

	my $sorted_genotype = join( ",", sort(@nt) );

	return $sorted_genotype;
}




# Recebe um array bidimensional contendo nucleotideos em cada celula
# e possivel cabecalho horizontal e vertical.
# Retorno o mesmo array em formato HTML e nucleotideo coloridos de acordo com base

sub color_nt_array {
	my ( $refArr, $num_col_headers, $num_row_headers, $refCols, $refHeader ) = @_;
	
		$out_html .= <<HTML;	
<style type="text/css">
nt_A { background-color: #3366FF; } 
nt_C { background-color: #66FF99; } 
nt_G { background-color: #FFCC00; } 
nt_T { background-color: #FF0000; } 
comma { color: white; background-color: #000000; }
</style>
HTML
	
	#$out_html .= "<table>\n";
	$out_html .= "<table id=NTTbl cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%;\">";
	
	$out_html .= "<tr>\n";
	foreach my $currHdrItem ( @{$refHeader} ){
		$out_html .= "<td><font size=1><center>$currHdrItem</center></font></td>";		
	}
	$out_html .= "\n</tr>\n";		
	
    
	my $row_num = 1;
	my $ref;
	foreach my $row ( @{$refArr} ) {
		$out_html .= "<tr>\n";
		my $col = 1;
		foreach my $cell ( @{$row} ) {
			
			$ref = $cell if $col == 3;
			
			if( not in_array($col, $refCols) ){
				$col++;
				next;
			}  
			
			$out_html .= "<td>";
			
			# It is a header			
			if( $col <= $num_col_headers || $row_num <= $num_row_headers ){
				$out_html .= "<center><font size=1>$cell</font></center>";
			}else{
				#$cell = $ref if $cell eq "";
				my $uc_cell = uc($cell);	
				#$uc_cell =~ s/(\S)/add_color_nt($1)/eg;
				
				$uc_cell =~ s/([ACGT])/<nt_$1>$1<\/nt_$1>/g;
				$uc_cell =~ s/,/<comma>-<\/comma>/g;
						
				$out_html .= $uc_cell;		
			}								
			$out_html .= "</td>";								
			$col++;
		}
		$out_html .= "\n</tr>\n";		
		$row_num++;
	}
	$out_html .= "</table>\n";
	return $out_html . "\n";
}

sub in_array{
	my ( $item, $arrRef ) = @_;
	
	foreach my $currItem ( @{$arrRef} ){
		 return 1 if $item eq $currItem; 
	}
	
	return 0;
}

sub add_color_nt{
	my ($nt) = @_;
		 
				if ( $nt eq "A" ) {
					$cor = "#3366FF";
				}

				elsif ( $nt eq "C" ) {
					$cor = "#66FF99";
				}

				elsif ( $nt eq "G" ) {
					$cor = "#FFCC00";
				}

				elsif ( $nt eq "T" ) {
					$cor = "#FF0000";
				}
				my $out = "<font color=\"$cor\">$nt</font>";
			
			
	return $out;
}

	
return 1;
	
	

