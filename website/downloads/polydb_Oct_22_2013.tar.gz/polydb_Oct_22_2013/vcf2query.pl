#!/usr/bin/env perl

use FindBin;
use lib "$FindBin::Bin";

use lib $ENV{vcf_pm_dir};
use lib $ENV{cgibin_root};

use DBI;
use Vcf;
use VCFDB;
use Data::Dumper;
use strict;
use IO::Handle;
use Carp;
use casa_constants_for_installer;
use Log::Log4perl;


my $debug = 1;

if( $debug == 1 ){
	$Carp::Verbose = 1;
}


STDOUT->autoflush(1);

# Starting logging
#sub getFileMode{ return "append"; };
Log::Log4perl->init( $FindBin::Bin . '/log4perl.conf' );
my $log = Log::Log4perl->get_logger();

$SIG{__WARN__} = sub {
        local $Log::Log4perl::caller_depth =
            $Log::Log4perl::caller_depth + 1;
        $log->warn( @_ );
};
    
$SIG{__DIE__} = sub {
        if($^S) {
            # We're in an eval {} and don't want log
            # this message but catch it later
            return;
        }
        $Log::Log4perl::caller_depth++;
        $log->logexit( @_ );
};

my $usage = "\nvcf2query.pl <vcf file list> <project name> <use genomeview 0|1> <generate boxplot 0|1> \n" .
            " <add column with full annotation when dumping 0|1 > \n\n";

die $usage if ( scalar(@ARGV) != 5 );

my $vcf_file_list = $ARGV[0];
my $project_name  = $ARGV[1];
my $genome_view   = $ARGV[2];
my $boxplot       = $ARGV[3];
my $dump_full_annot = $ARGV[4];


my @vcf_list;
my %sample_id;
my @sample_names;

# Connect to DB
my $dbh;

$dbh = DBI->connect($CASA::DSN, $CASA::DB_USER, $CASA::DB_PASSWORD) or die "Couldn't connect to $CASA::DB using string $CASA::DSN as $CASA::DB_USER\n" . DBI->errstr;  		

my $line_num = 1;
open VCF_LIST, $vcf_file_list or die "Unable to open the file \'$vcf_file_list\'";
while (<VCF_LIST>) {
	my $line = $_;
	chomp($line);
	
	if ( $line =~ /^#/ || $line =~ /^[\s\t]*$/ ){
		$line_num++;
		next;
	}	

	my @cols = split "\t", $line;

	if ( scalar(@cols) != 2 || $cols[0] eq "" || $cols[1] eq "" ) {
		die "\nError on line $line_num\n\n"
		  . "VCF file list should have the following format in every line:\n"
		  . "<sample name>\\t<full path to correspondent VCF>\\n\n\n";
	}

	my ( $name, $filename ) = @cols;

	$sample_id{$filename} = scalar(@vcf_list);
	push @vcf_list, $filename;

	push @sample_names, $name;
	$line_num++;
}
close(VCF_LIST);

# Header will be based on the first file
my $vcf = Vcf->new( file => $vcf_list[0] );
$vcf->parse_header();

my %fields;

my @info_fields;
my @filter_fields;
my @format_fields;

# VCF specification
# From http://www.1000genomes.org/node/101
#Possible Types for INFO fields are: Integer, Float, Flag, Character, and String.
#The Number entry is an Integer that describes the number of values that can be included with the
#INFO field. For example, if the INFO field contains a single number, then this value should be 1.
#However, if the INFO field describes a pair of numbers, then this value should be 2 and so on.
#If the number of possible values varies, is unknown, or is unbounded, then this value should be '.'.
#Possible Types are: Integer, Float, Character, String and Flag. The 'Flag' type indicates that the
#INFO field does not contain a Value entry, and hence the Number should be 0 in this case.
#The Description value must be surrounded by double-quotes.

my %FIELD_TYPE_TRANSLATION = (
	'Boolean'   => "BOOL",
	'Integer'   => "INTEGER",
	'Float'     => "FLOAT",
	'Flag'      => "BOOL",
	'Character' => "varchar(1)",
	'String'    => "varchar(255)"
);

foreach my $field_category ( ( 'INFO', 'FILTER', 'FORMAT' ) ) {
	my @headers = $vcf->get_header_line( key => $field_category );

	foreach my $items_arr_ref (@headers) {

		#print Data::Dumper->Dump([$items_arr_ref]);
		#getc();
		foreach my $items_hash_ref ( @{$items_arr_ref} ) {

			#print ">>" . Data::Dumper->Dump([$items_hash_ref]);
			#getc();
			foreach my $field ( values %{$items_hash_ref} ) {

				#print "Field type: $field_category"
				#  . "  Key: "
				#  . $field->{ID}
				#  . "  Type: "
				#  . $field->{Type}
				#  . "  Description: "
				#  . $field->{Description} . "\n";

				my $id               = $field->{ID};
				my $type             = $field->{Type};
				my $number_subfields = $field->{Number};
				my $desc             = $field->{Description};

				$fields{$id}{id}             = $id . "_" . $field_category;
				$fields{$id}{name}           = $id;
				$fields{$id}{desc}           = $desc;
				$fields{$id}{field_category} = $field_category;

				if ( $field_category eq "FILTER" ) {
					$fields{$id}{type}             = "Boolean";
					$fields{$id}{number_subfields} = 1;
					push( @filter_fields, $id );
				}
				elsif ( $field_category eq "INFO" ) {
					$fields{$id}{type}             = $type;
					$fields{$id}{number_subfields} = 1;

					if (   $number_subfields eq "."
						|| $number_subfields > 1
						|| $number_subfields == -1 )
					{
						$fields{$id}{type}             = "String";
						$fields{$id}{number_subfields} = 1;

						# IF number of subfields is not a number than raise an error
					}
					elsif ( $number_subfields =~ /\D/ ) {

carp "\nWarning: Header of file \'" . $vcf_list[0] . "\' !\n" .
 "Value of entry \'Number\' on field \'$id\' should be either a number or \'.\' for fields with variable number of subfields\n";
						$fields{$id}{type}             = "String";
						$fields{$id}{number_subfields} = 1;

					}

					push( @info_fields, $id );
				}
				elsif ( $field_category eq "FORMAT" ) {

					# TODO: Not dealing with subfields yet.
					# For the timebeing, fields containing subfields will be treated as
					# strings

					$fields{$id}{type}             = $type;
					$fields{$id}{number_subfields} = $number_subfields;

					if (   $number_subfields eq "."
						|| $number_subfields > 1
						|| $number_subfields == -1 )
					{
						$fields{$id}{type}             = "String";
						$fields{$id}{number_subfields} = 1;
					
						# IF number of subfields is not a number than raise an error
					}
					elsif ( $number_subfields =~ /\D/ ) {

carp "\nWarning: Header of file \'" . $vcf_list[0] . "\' !\n" .
 "Value of entry \'Number\' on field \'$id\' should be either a number or \'.\' for fields with variable number of subfields\n";

						if ( $id eq "PL" ) {
							$fields{$id}{type}             = "String";
							$fields{$id}{number_subfields} = 1;
						}
						else {
							$fields{$id}{type}             = $type;
							$fields{$id}{number_subfields} = 1;
						}
					}

					push( @format_fields, $id );
				}

			}
		}
	}
}

$vcf->close();

# Add a field that was found in the VCF content
# but not listed in the header
$fields{LowQual}{id}               = "LowQual_FILTER";
$fields{LowQual}{name}             = "LowQual";
$fields{LowQual}{type}             = "Boolean";
$fields{LowQual}{desc}             = "Below a quality value threshold (Check with either Sarah Young, Sean Sykes or Terrance Shea the effective quality threshold)";
$fields{LowQual}{number_subfields} = 1;  
$fields{LowQual}{field_category}   = "FILTER";
push( @filter_fields, $fields{LowQual}{name} );

my ($query_html ) = generate_query_html( \%fields, \@sample_names, $project_name, \@filter_fields );

# $dump_file_header contains the header of the dump file, file generated when user clicks download in the web front-end
my ($results_html, $dump_file_header) =
  generate_results_html( \%fields, \@sample_names, $project_name, \@filter_fields );

open HTML_OUT, ">" . $project_name . "_query_database";
print HTML_OUT $query_html;
close(HTML_OUT);

open HTML_OUT, ">" . $project_name . "_query_results";
print HTML_OUT $results_html;
close(HTML_OUT);

# Add fixed fields
$fields{qual}{id}               = "qual";
$fields{qual}{name}             = "qual";
$fields{qual}{type}             = "Float";
$fields{qual}{number_subfields} = 1;
$fields{qual}{field_category}   = "FIXED";

my ($code) = generate_back_end_code( \%fields, \@sample_names, $project_name, \@filter_fields, $dump_file_header );

open CODE_OUT, ">" . $project_name . "_back_end.pm";
print CODE_OUT $code;
close(CODE_OUT);

$dbh->disconnect();

exit(0);

sub generate_query_html {
	my ( $ref_fields_hash, $sample_list_arr_ref, $project_name, $filters_arr_ref ) = @_;
	
	my $qual_sample_check_box = generate_sample_check_boxes( $sample_list_arr_ref, 'qual', 
															 'Float', 'qual' );
															 
	my $sample_names_table = generate_sample_names_table($sample_list_arr_ref);
	
	my @chrom_names = VCFDB::get_chrom_names( $dbh, $project_name );

	my $html_out = <<HTML;
  <!-- GENOMIC REGION -->
  <span style="font-family: Arial,Helvetica,sans-serif;"><b>Select all SNPs located on:</b></span><BR>
  <span style="font-family: Arial,Helvetica,sans-serif;">Chromosome</span>
  <select name="chrom" onchange='OnChromChange(this.form.chrom);'>
  <option value="all">all</option>
HTML
	foreach my $currChrom ( @chrom_names ){
    	$html_out .= "<option value=\"$currChrom\">$currChrom</option>\n";
	}

    $html_out .= <<HTML;
  </select>
  <BR><BR>
  <span style="font-family: Arial,Helvetica,sans-serif;">Coordinates:</span><BR> 
  <span style="font-family: Arial,Helvetica,sans-serif;">from</span>
  <input name="chrom_coord_start" onkeyup='OnChromCoordStartChange(this.form.chrom_coord_start);'>
  <span style="font-family: Arial,Helvetica,sans-serif;">to</span>
  <input name="chrom_coord_end">
  <BR>
  <BR>
  
  <BR>
  <span style="font-family: Arial,Helvetica,sans-serif;">Gene locus id (e.g. $CASA::EXAMPLE_LOCUS_ID):</span><BR> 
  <small>Enclose in single quotes for exact matches (e.g. '$CASA::EXAMPLE_LOCUS_ID')</small> <BR>  
  <input name="gene">
  <BR>

  <BR>
  <span style="font-family: Arial,Helvetica,sans-serif;">Gene functional annotation (e.g. $CASA::EXAMPLE_FUNC_ANNOT):</span><BR> 
  <input name="gene_annotation">
  <BR>
 
  <BR>
  <span style="font-family: Arial,Helvetica,sans-serif;">Variance type:</span><BR> 
	<input type="radio" name="var_type" value="disregard" checked="yes"/> Disregard<br/>  	
	<input type="radio" name="var_type" value="SUBSTITUTION"/> Substitution<br/>  		
	<input type="radio" name="var_type" value="INSERTION" /> Insertion<br/>
	<input type="radio" name="var_type" value="DELETION" /> Deletion<br/>  
  <BR>  

  <BR>
  <span style="font-family: Arial,Helvetica,sans-serif;">Substitution type:</span><BR> 
	<input type="radio" name="var_syn_nsyn" value="disregard" checked="yes"/> Disregard<br/>
	<input type="radio" name="var_syn_nsyn" value="SYN" /> Synonymous<br/>  	
	<input type="radio" name="var_syn_nsyn" value="NSY" /> Non-synonymous<br/>
	<input type="radio" name="var_syn_nsyn" value="NON" /> Premature STOP codon <br/>  
	<input type="radio" name="var_syn_nsyn" value="RTH" /> Readthrough. Disrupted STOP codon <br/>  
  <BR>  
  
  
  <!-- Number of samples different than reference -->
  <span style="font-family: Arial,Helvetica,sans-serif;">Return positions with the following number of samples different than the reference genotype:</span><BR>

  <select name="operator_one_diff_reference">
    <option value="equals_to"> = </option>
    <option value="greater_than"> &gt; </option>
    <option value="greater_than_or_equal"> &ge; </option>
    <option value="lower_than"> &lt; </option>
    <option value="lower_than_or_equal"> &le; </option>
  </select>
  <input name="thre_one_diff_reference">
  AND
  <select name="operator_two_diff_reference">
    <option value="greater_than"> &gt; </option>
    <option value="greater_than_or_equal"> &ge; </option>
    <option value="lower_than"> &lt; </option>
    <option value="lower_than_or_equal"> &le; </option>
  </select>
  <input name="thre_two_diff_reference">
 <BR>
 <BR>
 <BR>
  
  
  
<!-- Genotype equations-->
  <span style="font-family: Arial,Helvetica,sans-serif;"><b>Genotype equations</b></span><BR>
  
  <span style="font-family: Arial,Helvetica,sans-serif;">
  Example 1: <b>ref = s1</b></span> <BR>
  Reference genotype EQUALS to sample 1.<BR><BR>
  
  <span style="font-family: Arial,Helvetica,sans-serif;">
  Example 2: <b> ( ref = s2 AND ref = s3 ) OR s5 != 'A'</b></span> <BR>
  EITHER reference genotype EQUALS to sample 2 and 3 OR sample 5 DIFFERENT than 'A'.<BR><br>
    
  Range and set of samples can be defined using the following syntax:<br>
  - Range: <span style="font-family: Arial,Helvetica,sans-serif;"><b>s3..s10</b></span><br>
  - Set: <span style="font-family: Arial,Helvetica,sans-serif;"><b>(s12,s13,s15)</b></span><br>
  <span style="font-family: Arial,Helvetica,sans-serif;">
  Example 3: <b> s2 != s3..s10 AND s11 != (s12,s13,s15)</b></span> <BR>
  Obs.: These constructs can be used in only one of the operands per each '=' and '!=' operator.<br>   
  That means that equations like <span style="font-family: Arial,Helvetica,sans-serif;"><b>'s1..s4 != s6..s10'</b></span> are not allowed. <br><br>
  
  Optionally, users can specify the number of samples from a list or range that needs to meet the imposed condition.<br>
  <span style="font-family: Arial,Helvetica,sans-serif;">
  Example 4: <b> s2 != s3..s10[6]</b></span> <BR>
  Sample 2 DIFFERENT than <b>6</b> samples within the range s3..s10<br> 
  Obs.: The usage of this construct in ranges or lists with more than 8 samples will cause a significant delay in query reponse.
  Please avoid it.<br>
    
  $sample_names_table

  Genotype equation:<br>
  <textarea rows="5" cols="60" name="genotype_equation"></textarea>
  <BR>
  <BR> 
  
  <input name="Submit" value="Submit query!" type="submit">
  <BR>
  <BR>
     
    
  <!-- qual-->
  <span style="font-family: Arial,Helvetica,sans-serif;">Quality score</span><BR>

  <select name="operator_one_qual">
    <option value="equals_to"> = </option>
    <option value="greater_than"> &gt; </option>
    <option value="greater_than_or_equal"> &ge; </option>
    <option value="lower_than"> &lt; </option>
    <option value="lower_than_or_equal"> &le; </option>
  </select>
  <input name="thre_one_qual">
  AND
  <select name="operator_two_qual">
    <option value="greater_than"> &gt; </option>
    <option value="greater_than_or_equal"> &ge; </option>
    <option value="lower_than"> &lt; </option>
    <option value="lower_than_or_equal"> &le; </option>
  </select>
  <input name="thre_two_qual">
 <BR>
 $qual_sample_check_box
 <BR>			   
HTML

	######################################
	## HTML for filters
	######################################

	if ( scalar( @{$filters_arr_ref} ) != 0 ) {
		$html_out .= <<HTML;
<!-- FILTERS -->
<span style="font-family: Arial,Helvetica,sans-serif;"><b>Filtering OUT:</b></span><BR>
HTML

	}
	foreach my $curr_field_id ( @{$filters_arr_ref} ) {
		my $name = $ref_fields_hash->{$curr_field_id}{name};
		my $type = $ref_fields_hash->{$curr_field_id}{type};
		my $desc = $ref_fields_hash->{$curr_field_id}{desc};

		my $sample_check_box = generate_sample_check_boxes( $sample_list_arr_ref, $name, $type, $curr_field_id );

		$html_out .= <<HTML;
<INPUT type="checkbox" name=$name value="true"> $name - $desc </option>
<BR>
	$sample_check_box
HTML

		if ( scalar( @{$filters_arr_ref} ) != 0 ) {
			$html_out .= <<HTML;
<BR>
HTML

		}
	}

	$html_out .= <<HTML;
<BR>
<span style="font-family: Arial,Helvetica,sans-serif;"><b>User defined VCF fields:</b></span><BR>

HTML

	######################################
	## User defined VCF fields
	######################################

	foreach my $curr_field ( values %{$ref_fields_hash} ) {

		my $id       = $curr_field->{id};
		my $name     = $curr_field->{name};
		my $type     = $curr_field->{type};
		my $desc     = $curr_field->{desc};
		my $category = $curr_field->{field_category};

		#print "Processing $name ...\n";

		# Field TYPE

		#	'Boolean'   => "BOOL",
		#	'Integer'   => "INTEGER",
		#	'Float'     => "FLOAT",
		#	'Flag'      => "BOOL",
		#	'Character' => "varchar(1)",
		#	'String'    => "varchar(255)"

		if ( $category eq "INFO" || $category eq "FORMAT" || $category eq "FIXED" ) {
			if ( $type eq 'Integer' || $type eq 'Float' ) {

				$html_out .= <<HTML;
  <!-- $name-->
  <span style="font-family: Arial,Helvetica,sans-serif;">$name</span><BR>
  <span style="font-family: Arial,Helvetica,sans-serif; font-size : 11px">$desc</span><BR>

  <select name="operator_one_$name">
    <option value="equals_to"> = </option>
    <option value="greater_than"> &gt; </option>
    <option value="greater_than_or_equal"> &ge; </option>
    <option value="lower_than"> &lt; </option>
    <option value="lower_than_or_equal"> &le; </option>
  </select>
  <input name="thre_one_$name">
  AND
  <select name="operator_two_$name">
    <option value="greater_than"> &gt; </option>
    <option value="greater_than_or_equal"> &ge; </option>
    <option value="lower_than"> &lt; </option>
    <option value="lower_than_or_equal"> &le; </option>
  </select>
  <input name="thre_two_$name">
 <BR>		
HTML

			}
			elsif ( $type eq 'Character' || $type eq 'String' ) {

				$html_out .= <<HTML;
			
  <!-- $name-->
  <span style="font-family: Arial,Helvetica,sans-serif;">$name</span><BR>
  <span style="font-family: Arial,Helvetica,sans-serif; font-size : 11px">$desc</span><BR>
  <input name="$name">
  <BR>
HTML
			}
			elsif ( $type eq 'Boolean' || $type eq 'Flag' ) {

				$html_out .= <<HTML;
			
  <!-- $name-->
  <span style="font-family: Arial,Helvetica,sans-serif;">$name</span><BR>
  <span style="font-family: Arial,Helvetica,sans-serif; font-size : 11px">$desc</span><BR>
	<input type="radio" name="$name" value="disregard" checked="yes"/> Disregard<br/>  	
	<input type="radio" name="$name" value="true" /> True<br/>
	<input type="radio" name="$name" value="false" /> False<br/>
	<BR>
HTML
			}
			else {
				die "Unknown field type \'$type\'\n";
			}
			my $sample_check_box = generate_sample_check_boxes( $sample_list_arr_ref, $name, $type, $id );
			$html_out .= <<HTML;
	$sample_check_box
	<BR>	
HTML

		}

	}

	return ($html_out);
}

sub generate_results_html {
	my ( $ref_fields_hash, $sample_list_arr_ref, $project_name, $filters_arr_ref ) = @_;
	
	# $dump_file_header contains the header of the dump file, file generated when user clicks download in the web front-end
	my $dump_file_header = '';
			
	my $html_out = "";

	if( $genome_view ){
		$html_out = <<HTML;
 	  <a href="http://$CASA::GENOMEVIEW_URL/" target="_blank"> Start Genomeview </a> <br>
HTML
	}


	$dump_file_header .= "chrom\\tposition\\treference\\tlocus\\tgene annotation\\t";
	
	$html_out = <<HTML;

[% nt_grid_html %]

<BR>
  <span style="font-family: Arial,Helvetica,sans-serif;">
   <b>SYN</b>-synonymous substitution,
   <b>NSY</b>-synonymous substitution, 
   <b>NON</b>-premature STOP codon, 
   <b>RTH</b>-readthrough, disrupted STOP codon.
  </span>
	
  <div style="overflow:auto; width:100%">
    <table  cellpadding="0" cellspacing="0" style="width:100%;">
        <tr>
            <td> 
  
            <table id=mainTbl>
 		<tr>
 			<!-- Chromosome -->
 				<th><span title="header=[<img src='/templates/casa/javascript/info.gif' style='vertical-align:middle'>] body=[Chromosome]" style="cursor:pointer">Chromosome</span></th>

 			<!-- SNPchromosomic coordinates -->
 				<th><span title="header=[<img src='/templates/casa/javascript/info.gif' style='vertical-align:middle'>] body=[SNP chromosomic coordinates]" style="cursor:pointer">Coordinates</span></th>
 				 				
 			<!-- Reference -->
 				<th><span title="header=[<img src='/templates/casa/javascript/info.gif' style='vertical-align:middle'>] body=[Reference]" style="cursor:pointer">Reference</span></th>
 				
 			<!-- Gene -->
 				<th><span title="header=[<img src='/templates/casa/javascript/info.gif' style='vertical-align:middle'>] body=[Gene]" style="cursor:pointer">Gene</span></th>

 			<!-- Gene annotation-->
 				<th><span title="header=[<img src='/templates/casa/javascript/info.gif' style='vertical-align:middle'>] body=[Gene annotation]" style="cursor:pointer">Gene annotation</span></th>
 				
 		
HTML
	for (
		my $cont_samples = 0 ;
		$cont_samples < scalar( @{$sample_list_arr_ref} ) ;
		$cont_samples++
	  )
	{
		my $sample_name = $sample_list_arr_ref->[$cont_samples];
		$sample_name =~ s/_TY-2482.filtered.90pct\S+//;
		my $sample_alias = "s$cont_samples";
		my $header       = $sample_name . " ($sample_alias)";
		my $header_subst_type = "subst.type ($sample_alias)";
		my $header_full_annot = "full annot. ($sample_alias)";

		my $header_dmp            = $sample_name . "($sample_alias)";
		my $header_subst_type_dmp = "subst.type($sample_alias)";

		$dump_file_header .= "$header_dmp\\t";
		$dump_file_header .= "$header_subst_type_dmp\\t";
		$dump_file_header .= "$header_full_annot\\t" if ( $dump_full_annot );
		
		$html_out .= <<HTML;

 			<!-- $header -->
 				<th><span title="header=[<img src='/templates/casa/javascript/info.gif' style='vertical-align:middle'>] body=[$header]" style="cursor:pointer">$header</span></th>

 			<!-- $header substitution type -->
 				<th><span title="header=[<img src='/templates/casa/javascript/info.gif' style='vertical-align:middle'>] body=[substitution type($sample_alias)]" style="cursor:pointer">$header_subst_type</span></th>
 				
 				
HTML

	}

	# (2 x samples) + chrom + reference + position + gene + gene_annotation =  3 x samples + 5
	my $rows = 2 * scalar( @{$sample_list_arr_ref} ) + 5;
	
			
	$html_out .= <<HTML;
</tr>
 		[% USE table(results_table, rows=$rows) %]
 		<tr>
 		[% FOREACH cols = table.cols %]
 			[% FOREACH item = cols  %] 			    
HTML
  				
	if( $genome_view ){
		$html_out .= <<HTML;
  				<td><font size=1> <a href="#" onClick="javascript:setInstructAllInstancesGV();javascript:positionGV('[% cols.0 %]:[% cols.1 - 50 %]:[% cols.1 + 50 %]');">[% item %]</a> </font></td>
HTML
	}else{
		$html_out .= <<HTML;
  				<td><font size=1> [% item %]</font></td>
HTML
		
	}

	$html_out .= <<HTML;
 			[% END %]
 		</tr>
 		[% END %]				
 		</table>
          </td>
        </tr>
    </table>
</div> 		
HTML

	#Removing surplus tab
	$dump_file_header =~ s/\\t$/\\n/;

	return ($html_out, $dump_file_header);
}

sub generate_back_end_code {
	my ( $ref_fields_hash, $sample_list_arr_ref, $project_name, $filters_arr_ref, $dump_file_header ) = @_;
	my $pm_name = $project_name . "_back_end";

	my $code_out .= <<CODE;
package DatabaseSpecificBackEnd;

use GenotypeEquations;

CODE
	
	# These are the declarations of headers and columns of the 
	# nucleotide grid shown on the results page
	my $num_samples =scalar( @{$sample_list_arr_ref} );
	my $array_header_declaration = nt_grid_header_list( $num_samples );
	my $array_col_declaration    = nt_grid_col_list( $num_samples );
	
	
	$code_out .= <<CODE;

\@NT_GRID_HEADER = $array_header_declaration;
\@NT_GRID_COLS = $array_col_declaration;
\$DUMP_FILE_HEADER = \"$dump_file_header\";

sub generate_where{
	
		my (\$params) = \@_;

		my \$operator_one;
		my \$operator_two;
		my \$thre_one;
		my \$thre_two;
		my \$value;
		my \$is_strict; 
		my \$add_where = "";
		
		my \$chrom = \$params->{chrom};
		my \$chrom_coord_start = \$params->{chrom_coord_start};
		my \$chrom_coord_end = \$params->{chrom_coord_end};
		

		# Genomic coordinates
		if( \$chrom ne "all" ){
			\$add_where .= "chrom = \'\$chrom\' AND ";
		}

		if( \$chrom_coord_start ne "" ){
			\$add_where .= "position >= \$chrom_coord_start AND ";
		}
		if( \$chrom_coord_end ne "" ){
			\$add_where .= "position <= \$chrom_coord_end AND ";
		}						
		
							

		# Genotype equation
		my \$genotype_equation = \$params->{genotype_equation};
		
		if( \$genotype_equation ne "" ){	
			\$genotype_equation = GenotypeEquations::expand( \$genotype_equation );						
			\$add_where .= \$genotype_equation . " AND ";
		}		

		# Number of differences when compared to reference
		\$operator_one    = \$params->{operator_one_diff_reference};
		\$operator_two    = \$params->{operator_two_diff_reference};
		\$thre_one        = \$params->{thre_one_diff_reference};
		\$thre_two        = \$params->{thre_two_diff_reference};
		
		if( \$thre_one ne "" ){
			\$operator_one = mysql_numeric_op( \$operator_one );
			\$add_where .= "num_samples_diff_reference \$operator_one \$thre_one  AND ";
		}
			
		if( \$thre_two ne "" ){
			\$operator_two = mysql_numeric_op( \$operator_two );
			\$add_where .= "num_samples_diff_reference \$operator_two \$thre_two  AND ";
		}

		
		# Var_type
		\$value    = \$params->{var_type};
		if( \$value ne "disregard" ){
			\$add_where .= "var_type  like \'%\$value%\' AND ";
		}
				
		
CODE

$code_out .= <<'CODE';

		# Gene		
		$value    = $params->{gene};
		if( $value ne "" ){
			my $gene = $value;
			
			# Removing spaces from ends
			$gene =~ s/^\s+//;
			$gene =~ s/\s+$//;
			
			# If gene is quoted try exact match 
			if( $gene =~ /\'[\w\W]+?\'/ ){
				$add_where .= "gene like $gene AND ";
			}else{
				$add_where .= "gene like   \'%$gene%\' AND ";			
			}
			
		}			


		# Gene annotation		
		$value    = $params->{gene_annotation};
		if( $value ne "" ){

			my $gene_annotation = $value;
			
			# Removing spaces from ends
			$gene_annotation =~ s/^\s+//;
			$gene_annotation =~ s/\s+$//;
						
			$add_where .= "gene_annotation like   \'%$gene_annotation%\' AND ";
		}			



		# Void
		$value    = $params->{void};
		
		if( $value ne "" ){
			my @void_samples = split( '%', $value );

			# Creates a string of bits representing all the samples that are valid
			# this is the equivalent of negating the bit string representing all void samples
			my $negate_bit_string = GenotypeEquations::sample_list_to_negate_bit_string( \@void_samples, 
			
CODE

$code_out .= "$num_samples );";			
			
$code_out .= <<'CODE';			
			# The commmand below performs a bitwise AND operation between a bit string representing all valid 
			# samples against the bit string representing all samples which are different than 
			# the reference. The result consists of all VALID samples which are different than the 
			# reference. 
			# Then, all 0 are removed (replace cmd) from this bit string and left over 1's are counted (length cmd).
			# The result represents the number of VALID samples which are different than the reference.
			# This number should be at least one
			$add_where .= " length ( replace( ( B\'$negate_bit_string\' & diff_reference )::text,'0','' ) ) >= 1 AND ";
			
		}
CODE

#################################################################
# Processed fields (mostly from Brians script)
# variance type and subtitution type


		for my $name ("var_syn_nsyn" ){
				my $str = "\$add_where .= \"( \";\n";
					
				for (
					my $cont_samples = 0 ;
					$cont_samples < scalar( @{$sample_list_arr_ref} ) ;
					$cont_samples++
				  )
				{
					my $sample_name  = "s$cont_samples";
					my $sample_field = $name . '[' . $cont_samples . ']';
					$str .= "\$add_where .= \"$sample_field  like \\\'\%\$value%\\\' OR \";\n";
				}
				$str =~ s/OR \";\n$/) AND \";\n/;
				$code_out .= <<CODE;				
		\$value    = \$params->{$name};
		if( \$value ne "disregard" ){
			$str
		}
CODE

		}

#################################################################

	foreach my $curr_field ( values %{$ref_fields_hash} ) {

		my $id       = $curr_field->{id};
		my $name     = $curr_field->{name};
		my $type     = $curr_field->{type};
		my $desc     = $curr_field->{desc};
		my $category = $curr_field->{field_category};

		#print "Processing $name ...\n";

		# Field TYPE

		#	'Boolean'   => "BOOL",
		#	'Integer'   => "INTEGER",
		#	'Float'     => "FLOAT",
		#	'Flag'      => "BOOL",
		#	'Character' => "varchar(1)",
		#	'String'    => "varchar(255)"

		if ( $category eq "INFO" || $category eq "FORMAT" || $category eq "FIXED" ) {

			$code_out .= <<CODE;
		\$is_strict    = \$params->{is_strict_$name};
CODE

			if ( $type eq 'Integer' || $type eq 'Float' ) {

				my $str_one = "";
				my $str_two = "";
				for (
					my $cont_samples = 0 ;
					$cont_samples < scalar( @{$sample_list_arr_ref} ) ;
					$cont_samples++
				  )
				{
					my $sample_name  = "s$cont_samples";					
					my $sample_field = $id . '[' . $cont_samples . ']';

					$str_one .=
					  "\$add_where .= \"( $sample_field  \$operator_one \$thre_one OR $sample_field IS NULL ) AND \" if \$is_strict =~ \"$sample_name%\";\n";
					$str_two .=
					  "\$add_where .= \"( $sample_field  \$operator_two \$thre_two OR $sample_field IS NULL ) AND \" if \$is_strict =~ \"$sample_name%\";\n";
				}

				$code_out .= <<CODE;
		\$operator_one    = \$params->{operator_one_$name};
		\$operator_two    = \$params->{operator_two_$name};
		\$thre_one        = \$params->{thre_one_$name};
		\$thre_two        = \$params->{thre_two_$name};
		
		# $name
		if( \$thre_one ne "" ){
			\$operator_one = mysql_numeric_op( \$operator_one );
			$str_one
		}			
		if( \$thre_two ne "" ){
			\$operator_two = mysql_numeric_op( \$operator_two );
			$str_two
		}
CODE

			}
			elsif ( $type eq 'Character' || $type eq 'String' ) {

				my $str = "";
				for (
					my $cont_samples = 0 ;
					$cont_samples < scalar( @{$sample_list_arr_ref} ) ;
					$cont_samples++
				  )
				{
					my $sample_name  = "s$cont_samples";
					my $sample_field = $id . '[' . $cont_samples . ']';

					$str .=
					  "\$add_where .= \"( $sample_field  = \\\'\$value\\\' OR $sample_field IS NULL )  AND \" if \$is_strict =~ \"$sample_name%\";\n";
				}

				$code_out .= <<CODE;
				
		\$value    = \$params->{$name};
		if( \$value ne "" ){
			$str
		}
CODE

			}
			elsif ( $type eq 'Boolean' || $type eq 'Flag' ) {
				my $str = "";
				for (
					my $cont_samples = 0 ;
					$cont_samples < scalar( @{$sample_list_arr_ref} ) ;
					$cont_samples++
				  )
				{
					my $sample_name  = "s$cont_samples";
					my $sample_field = $id . '[' . $cont_samples . ']';

					$str .=
					  "\$add_where .=  \"( $sample_field  = \\\'\$value\\\' OR $sample_field IS NULL ) AND \" if \$is_strict =~ \"$sample_name%\";\n";
				}

				$code_out .= <<CODE;
				
		\$value    = \$params->{$name};
		if( \$value ne "disregard" ){
			$str
		}
CODE
			}

		}
	}

	###################################
	# Generating filters back-end
	###################################

	foreach my $item ( @{$filters_arr_ref} ) {

		my $str = "";
		for (
			my $cont_samples = 0 ;
			$cont_samples < scalar( @{$sample_list_arr_ref} ) ;
			$cont_samples++
		  )
		{

			my $sample_name         = "s$cont_samples";
			my $sample_field_prefix = $item . "_filter[" . $cont_samples . "]";

			# Turning on the following filter
			# To turn it on you need to set the property associated to that filter
			# (ex. PoorMapping) to FALSE
			$str .=
			  "\$add_where .= \" ( $sample_field_prefix  = false OR $sample_field_prefix is NULL ) AND \" if \$is_strict =~ \"$sample_name%\";\n";
		}

		$code_out .= <<CODE;
		\$value    = \$params->{$item};
		\$is_strict    = \$params->{is_strict_$item};
		
				
		if( \$value ne "" ){				 				 
					$str
		}		
CODE
	}

###################################

	$code_out .= <<CODE;
		if( \$add_where ne "" ){
			\$add_where =~ s/ AND \$//;
			\$add_where = " where \$add_where ";
		}
		return \$add_where;
	}
	
sub mysql_numeric_op{
	my (\$op_str) = \@_;
	
	my \$op_mysql;
	
	\$op_mysql = ">"  if( \$op_str eq "greater_than" );
	\$op_mysql = ">=" if( \$op_str eq "greater_than_or_equal" );
	\$op_mysql = "<"  if( \$op_str eq "lower_than" );
	\$op_mysql = "<=" if( \$op_str eq "lower_than_or_equal" );
	\$op_mysql = "="  if( \$op_str eq "equals_to" );
	
	return \$op_mysql;
}

sub generate_order_by{
	return "order by $project_name.id_key_sorted";
}

CODE

	my $select_from = "select chrom, position, reference, gene, gene_annotation, ";
	my $dump_select_from = "select chrom, position, reference, gene, gene_annotation, ";
	for (
		my $cont_samples = 0 ;
		$cont_samples < scalar( @{$sample_list_arr_ref} ) ;
		$cont_samples++
	  )
	{
		$select_from .= "alt[" . $cont_samples . "], ";
		$select_from .=  "var_syn_nsyn[" . $cont_samples . "], ";
		
		$dump_select_from .=   "alt[" . $cont_samples . "], ";   
		$dump_select_from .=   "var_syn_nsyn[" . $cont_samples . "], ";   
		$dump_select_from .=   "full_annot[" . $cont_samples . "], ";   
	}
	
	$select_from =~ s/, $/ from $project_name /;
	
	my $full_annot_table = $project_name;
	$full_annot_table =~ s/_sorted//;
	$full_annot_table .= "_full_annot"; 
	
	$dump_select_from =~ s/, $//;
	$dump_select_from .= " from $project_name " .
	     "INNER JOIN $full_annot_table ON ( $project_name.id_key_sorted = $full_annot_table.id_key_sorted ) ";

	$code_out .= <<CODE;
sub generate_select_from{
	return "$select_from";
}
CODE

if( $dump_full_annot ){

	$code_out .= <<CODE;
sub generate_dump_select_from{
	return "$dump_select_from";
}
CODE

}else{

	$code_out .= <<CODE;
sub generate_dump_select_from{
	return "$select_from";
}
CODE
	
	
}


	$code_out .= <<CODE;
return 1;
CODE
	return ($code_out);
}


# These are functions that generate the 
# declarations of headers and columns of the 
# nucleotide grid shown on the results page

# In case of 21 samples the result should be
#qw(chrom pos ref 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 );

sub nt_grid_header_list{
	my ($sample_num) = @_;
	
	my $str = "qw( chrom pos ref ";
	
	for(my $ind = 0; $ind < $sample_num; $ind++ ){
		$str .= "$ind ";
	}
	
	$str .= ")";
	return $str
}

# In case of 21 samples the result should be
# qw( 1 2 3 6 8 10 12 14 16 18 20 22 24 26 28 30 32 34 36 38 40 42 44 46 48 );
sub nt_grid_col_list{
	my ($sample_num) = @_;

	my $str = "qw( 1 2 3 ";
	my $number_of_sample_based_fields = 2;
	
	for(my $ind = 0; $ind < $sample_num; $ind++ ){
		my $col_num = 6 + ( $ind * $number_of_sample_based_fields );
		$str .= "$col_num ";
	}
	
	$str .= ")";
	return $str
}

sub generate_sample_names_table {
	my ($sample_list_arr_ref) = @_;

	my $html = <<HTML;
	
   <div id="tableContainer" class="tableContainer">
<table border="0" cellpadding="0" cellspacing="0" width="100%" class="scrollTable">
<thead class="fixedHeader">
	<tr>
        	<th>Alias</th><th>Sample name</th><th>DO NOT SHOW</th><th>DO NOT REPORT positions in which this/these SAMPLE(s) are the only difference(s) to the REFERENCE</th>
	</tr>
</thead>
<tbody class="scrollContent">
HTML
	for (
		my $cont_samples = 0 ;
		$cont_samples < scalar( @{$sample_list_arr_ref} ) ;
		$cont_samples++
	  )
	{
		my $sample_name = $sample_list_arr_ref->[$cont_samples];
		$sample_name =~ s/_TY-2482.filtered.90pct\S+//;

		my $sample_alias = "s$cont_samples";
		my $checked      = "";
		$checked = "CHECKED" if $cont_samples <= 17;

		$html .= <<HTML;
		              <tr>
		              <td> $sample_alias </td><td>$sample_name </td>
		              <td><INPUT type="checkbox" name=do_not_show value="$sample_alias%"></td>
		              <td><INPUT type="checkbox" name=void value="$sample_alias%"></td>
		              </tr>
HTML

	}

	$html .= <<HTML;
</tbody>
</table>
</div>
HTML
	return $html;

}

sub generate_sample_check_boxes {
	my ( $sample_list_arr_ref, $field_name, $field_type, $field_id ) = @_;

	my $html = <<HTML;
<BR>
 <span style="font-family: Arial,Helvetica,sans-serif; font-size : 11px">Impose it to:</span>
 <div style="overflow:auto; width:100%">
    <table cellpadding="0" cellspacing="0" style="width:100%;">
        <tr>
HTML
	for (
		my $cont_samples = 0 ;
		$cont_samples < scalar( @{$sample_list_arr_ref} ) ;
		$cont_samples++
	  )
	{
		my $sample_name = "s$cont_samples";
		my $sample_num  = $cont_samples;
		my $checked     = "CHECKED";
		my $sample_field      =  $field_id . "[" . $sample_num . "]";
		my $box_plot_img      = "box_plot." . $project_name . "." . $sample_field . ".png";
		my $box_plot_dir      = "http://$CASA::WEB_SERVER_AND_PORT/images";
		my $box_plot_path     = $box_plot_dir . "/" . $box_plot_img;

		
		if( $boxplot && ( $field_type eq "Float" || $field_type eq "Interger" )  ){

			my $number_non_null_values = boxplot( $project_name, $sample_field );
			
			if( $number_non_null_values != 0  ){
				$html .= <<HTML;
		         	  <td><font size=1>
		              <INPUT type="checkbox" name=is_strict_$field_name value="$sample_name%" $checked> 
		              $sample_name 
		              </option>
		              <img src="$box_plot_path">
		              </td>
HTML
			}else{
			$html .= <<HTML;
		              <td><font size=1>
		              <INPUT type="checkbox" name=is_strict_$field_name value="$sample_name%" $checked>
		              $sample_name 
		              </option>
		              <b>NO VALUES</b>
		              </td>
HTML
			}
		}else{
			$html .= <<HTML;
		              <td><font size=1>
		              <INPUT type="checkbox" name=is_strict_$field_name value="$sample_name%" $checked>
		              $sample_name 
		              </option>
		              </td>
HTML
		}



	}

	$html .= <<HTML;
        </tr>
    </table>
</div> 		
<BR>
HTML
	return $html;

}

sub not_NULL {

}

sub boxplot {
	my ( $project_name, $field ) = @_;
	
	print STDERR "Generating box plot for field \'$field\'...\n";

	my $filename_base = "box_plot." . $project_name . "." . $field;
	my $path          = $CASA::TEMPLATE_DIR . "/images/";
	my $R_script_file = $path . $filename_base . ".R";
	my $query_result  = $path . $filename_base . ".txt";
	my $boxplot_graph = $path . $filename_base . ".png";
	
	

	# OUTFILE is the generateed R_script
	open( OUTFILE, ">$R_script_file" ) || croak "Creation of results file failed: $R_script_file.\n\t$!\n";

	# OUTFILE2 is the query result file
	open( OUTFILE2, ">$query_result" ) || croak "Creation of results file failed: $R_script_file.\n\t$!\n";

	#DBI variables
	my ( $dbh, $sth );

	#connects to databse
	$dbh = DBI->connect( $CASA::DSN, $CASA::DB_USER, $CASA::DB_PASSWORD )
	  or die "Couldn't connect to $CASA::DB using string $CASA::DSN as $CASA::DB_USER\n"
	  . DBI->errstr;

	#print "Field: $field\n";
	#return if $field !~ "qual";

	my $query = "select $field from $project_name where $field is not NULL;";
	print "Query: $query\n";

	#execute query
	$sth = $dbh->prepare($query);
	$sth->execute() or die "Can't execute SQL statement:\n$query\n", $sth->errstr(), "\n";


	my $num_records = 0;
	while ( my @row_array = $sth->fetchrow_array() ) {
		print OUTFILE2 "@row_array\n";
		$num_records++;
	}
	die "Problem in fetchrow_array(): ", $sth->errstr(), "\n" if $sth->err();

	$dbh->disconnect();

	print "Number of non-NULL values: " . $num_records . "\n"; 
	
	# Return if there is no valid values on this field
	return 0 if $num_records == 0;

	# prints name of query result file
	# print OUTFILE "/home/gcerqueira/local/apache2/htdocs/templates/casa/results/$query_result\n";
	# prints out the R code for the script
	print OUTFILE "polydb_data<-read.table(\"$query_result\")\;\n";
	print OUTFILE "attach(polydb_data)\;\n";
	print OUTFILE "png(filename = \'$boxplot_graph\', width = 80, height = 120)\;\n";
	print OUTFILE "par(oma=c(0,0,0,0))\;\n";
	print OUTFILE "par(mar=c(0,2,0,0))\;\n";
	print OUTFILE "boxplot(V1,data=V1,outline=FALSE)\;\n";

   #print OUTFILE "hist(V1, col=\"azure3\", main=\"Distribution of Age\", xlab=\"Age\", ylab=)\;\n";
	print OUTFILE "dev.off()\;\n";
	close OUTFILE;

	# utilizes R to generate plot
	`R --no-save < $R_script_file`;
	
	return $num_records;

#`cp /home/gcerqueira/local/apache2/cgi-bin/casa/polydb_hist_analysis.$sid.png /home/gcerqueira/local/apache2/htdocs/templates/casa/results/arc3_hist_analysis.$sid.png`;
#print "Done first boxplot!\n";
#getc();
}

	
	
	
	
	
	

